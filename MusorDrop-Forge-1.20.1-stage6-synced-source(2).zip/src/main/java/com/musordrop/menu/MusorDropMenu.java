package com.musordrop.menu;

import com.musordrop.game.LuckValues;
import com.musordrop.registry.ModMenus;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;

public class MusorDropMenu extends AbstractContainerMenu {
    private static final int BUTTON_SPIN = 0;
    private final SimpleContainer offers;
    private final DataSlot chanceData = DataSlot.standalone();
    private final DataSlot spinSequenceData = DataSlot.standalone();
    private final DataSlot spinWonData = DataSlot.standalone();
    private final DataSlot lastSpinChanceData = DataSlot.standalone();
    private int spinSequence;
    private boolean pendingSpinResult;
    private boolean pendingSpinWon;

    public MusorDropMenu(int id, Inventory playerInventory) {
        this(id, playerInventory, new SimpleContainer(2));
    }

    public MusorDropMenu(int id, Inventory playerInventory, FriendlyByteBuf buffer) {
        this(id, playerInventory, new SimpleContainer(2));
    }

    private MusorDropMenu(int id, Inventory playerInventory, SimpleContainer offers) {
        super(ModMenus.MUSOR_DROP_MENU.get(), id);
        checkContainerSize(offers, 2);
        this.offers = offers;
        offers.startOpen(playerInventory.player);

        this.addSlot(new Slot(offers, 0, 25, 55));
        this.addSlot(new Slot(offers, 1, 213, 55) {
            @Override
            public boolean mayPlace(ItemStack stack) { return false; }

            @Override
            public boolean mayPickup(Player player) { return false; }
        });

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInventory, col + row * 9 + 9,
                        47 + col * 18, 140 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInventory, col, 47 + col * 18, 198));
        }
        this.addDataSlot(chanceData);
        this.addDataSlot(spinSequenceData);
        this.addDataSlot(spinWonData);
        this.addDataSlot(lastSpinChanceData);
    }

    @Override
    public void broadcastChanges() {
        if (!offers.getItem(0).isEmpty() && !offers.getItem(1).isEmpty()) {
            chanceData.set(LuckValues.chanceBasisPoints(offers.getItem(0), offers.getItem(1)));
        } else {
            chanceData.set(0);
        }
        super.broadcastChanges();
    }

    public double getChancePercent() {
        return chanceData.get() / 100.0;
    }

    public int getSpinSequence() {
        return spinSequenceData.get();
    }

    public double getLastSpinChancePercent() {
        return lastSpinChanceData.get() / 100.0;
    }

    public boolean wasLastSpinWon() {
        return spinWonData.get() == 1;
    }

    public boolean hasValidOffer() {
        // Validate from the actual server-side slot contents, not the synchronized
        // DataSlot, which can be one update behind immediately after a click.
        return LuckValues.chanceBasisPoints(offers.getItem(0), offers.getItem(1)) > 0;
    }

    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (buttonId != BUTTON_SPIN || !(player instanceof ServerPlayer serverPlayer)) {
            return false;
        }
        if (pendingSpinResult || !hasValidOffer()) {
            serverPlayer.displayClientMessage(Component.literal("Положи предметы в оба слота!"), true);
            return false;
        }

        ItemStack stake = offers.getItem(0);
        ItemStack prize = offers.getItem(1);
        int chance = LuckValues.chanceBasisPoints(stake, prize);

        // Use the server-side random source so the client cannot decide the result.
        boolean won = serverPlayer.getRandom().nextInt(10000) < chance;
        lastSpinChanceData.set(chance);
        spinWonData.set(won ? 1 : 0);
        pendingSpinResult = true;
        pendingSpinWon = won;
        // DataSlot values are synchronized to the client. Incrementing the sequence
        // makes consecutive spins detectable even when their outcomes are identical.
        spinSequence = (spinSequence + 1) % 30000;
        spinSequenceData.set(spinSequence);

        // The stake is always consumed. The offered prize is transferred only on a win.
        offers.setItem(0, ItemStack.EMPTY);
        if (won) {
            // The right slot is only a reward preview/template; it is never consumed.
            ItemStack reward = prize.copy();
            if (!serverPlayer.getInventory().add(reward)) {
                serverPlayer.drop(reward, false);
            }
        }

        offers.setChanged();
        broadcastChanges();
        return true;
    }

    public void setSelectedReward(ItemStack reward) {
        offers.setItem(1, reward.copy());
        offers.setChanged();
        broadcastChanges();
    }

    public void finishSpinAnimation() {
        if (!pendingSpinResult) return;
        if (pendingSpinWon) {
            player.displayClientMessage(Component.literal("ПОБЕДА! Ты выиграл награду!"), false);
        } else {
            player.displayClientMessage(Component.literal("Не повезло! Ставка потеряна."), false);
        }
        pendingSpinResult = false;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack empty = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) return empty;

        ItemStack source = slot.getItem();
        ItemStack copy = source.copy();
        if (index == 1) return empty; // Reward slot is a non-consumable selection.
        if (index == 0) {
            if (!this.moveItemStackTo(source, 2, this.slots.size(), true)) return empty;
        } else if (!this.moveItemStackTo(source, 0, 1, false)) {
            return empty;
        }
        if (source.isEmpty()) slot.set(ItemStack.EMPTY);
        else slot.setChanged();
        return copy;
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        if (!player.level().isClientSide) {
            // Return anything still in the two offer slots. This covers closing the
            // screen before spinning and returning the unspent prize after a loss.
            offers.stopOpen(player);
            if (pendingSpinResult) finishSpinAnimation();
            ItemStack remainingStake = offers.removeItemNoUpdate(0);
            if (!remainingStake.isEmpty()) {
                player.getInventory().placeItemBackInInventory(remainingStake);
            }
            // Slot 1 is only a selected reward preview, not a real player item.
            offers.removeItemNoUpdate(1);
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    public SimpleContainer getOffers() {
        return offers;
    }
}
