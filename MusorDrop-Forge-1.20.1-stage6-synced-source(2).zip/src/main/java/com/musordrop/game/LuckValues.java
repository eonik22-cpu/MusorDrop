package com.musordrop.game;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Map;

/**
 * Luck points per one item.
 *
 * Confirmed values are explicit. Other values are a broad starter catalogue
 * and can be tuned later. Unknown modded items receive a safe default.
 */
public final class LuckValues {
    private static final Map<String, Integer> VALUES = new HashMap<>();

    static {
        // Confirmed by the player
        put(8000, "dragon_head");
        put(2000, "elytra");
        put(20, "bone_block");
        put(10, "glass_pane");
        put(12, "glass");
        // Mace is not present in Minecraft 1.20.1; this entry is harmless
        // and supports it automatically if the mod is later moved to 1.21+.
        put(800, "mace");

        // Glass: confirmed prices for every colour
        put(12, "white_stained_glass_pane", "orange_stained_glass_pane",
            "magenta_stained_glass_pane", "light_blue_stained_glass_pane",
            "yellow_stained_glass_pane", "lime_stained_glass_pane",
            "pink_stained_glass_pane", "gray_stained_glass_pane",
            "light_gray_stained_glass_pane", "cyan_stained_glass_pane",
            "purple_stained_glass_pane", "blue_stained_glass_pane",
            "brown_stained_glass_pane", "green_stained_glass_pane",
            "red_stained_glass_pane", "black_stained_glass_pane");
        put(15, "white_stained_glass", "orange_stained_glass",
            "magenta_stained_glass", "light_blue_stained_glass",
            "yellow_stained_glass", "lime_stained_glass",
            "pink_stained_glass", "gray_stained_glass",
            "light_gray_stained_glass", "cyan_stained_glass",
            "purple_stained_glass", "blue_stained_glass",
            "brown_stained_glass", "green_stained_glass",
            "red_stained_glass", "black_stained_glass");

        // Main resources and ores (starter suggestions)
        put(1, "dirt", "coarse_dirt", "rooted_dirt", "podzol", "mycelium");
        put(2, "sand", "flint");
        put(3, "gravel", "red_sand", "wheat_seeds", "melon_seeds",
            "pumpkin_seeds", "beetroot_seeds", "paper", "sugar_cane");
        put(5, "oak_log", "spruce_log", "birch_log", "jungle_log", "acacia_log",
            "dark_oak_log", "mangrove_log", "cherry_log", "bamboo",
            "coal", "wheat", "apple", "carrot", "potato", "beetroot",
            "cod", "feather", "leather", "book", "bone_meal");
        put(8, "clay_ball", "salmon", "glow_berries", "baked_potato");
        put(10, "iron_nugget", "copper_ingot", "crafting_table", "chest",
            "glass_bottle", "item_frame", "sign");
        put(15, "coal_ore", "furnace", "smoker", "blast_furnace",
            "glow_item_frame", "armor_stand", "bone");
        put(20, "iron_ore", "copper_ore", "terracotta", "sponge",
            "stone", "cobblestone", "granite", "diorite", "andesite",
            "prismarine", "boat", "barrel", "grindstone", "loom");
        put(25, "gold_ore", "redstone", "lapis_lazuli", "stonecutter",
            "cartography_table", "smithing_table", "turtle_helmet");
        put(30, "iron_ingot", "golden_carrot", "hopper",
            "sticky_piston", "repeater", "comparator", "dispenser",
            "dropper", "piston", "shulker_box");
        put(40, "diamond_ore", "emerald_ore", "minecart", "saddle",
            "bookshelf", "chiseled_bookshelf");
        put(50, "blaze_rod", "ender_pearl", "lead", "bell");
        put(60, "gold_ingot", "trapped_chest");
        put(80, "lapis_block");
        put(100, "obsidian", "redstone_ore", "end_crystal", "eye_of_ender");
        put(150, "diamond", "nether_star", "lodestone", "respawn_anchor");
        put(200, "netherite_scrap");
        put(300, "redstone_block", "netherite_ingot", "beacon");
        put(600, "diamond_block");
        put(700, "golden_apple");
        put(1000, "ancient_debris");
        put(1500, "netherite_block");
        put(3000, "enchanted_golden_apple");
        put(250, "wither_skeleton_skull");
        put(500, "dragon_breath");

        // Building/decor families (suggested values; all 16 colours equal)
        put(10, "white_wool", "orange_wool", "magenta_wool", "light_blue_wool",
            "yellow_wool", "lime_wool", "pink_wool", "gray_wool",
            "light_gray_wool", "cyan_wool", "purple_wool", "blue_wool",
            "brown_wool", "green_wool", "red_wool", "black_wool");
        put(15, "white_carpet", "orange_carpet", "magenta_carpet", "light_blue_carpet",
            "yellow_carpet", "lime_carpet", "pink_carpet", "gray_carpet",
            "light_gray_carpet", "cyan_carpet", "purple_carpet", "blue_carpet",
            "brown_carpet", "green_carpet", "red_carpet", "black_carpet");
        put(15, "white_concrete", "orange_concrete", "magenta_concrete", "light_blue_concrete",
            "yellow_concrete", "lime_concrete", "pink_concrete", "gray_concrete",
            "light_gray_concrete", "cyan_concrete", "purple_concrete", "blue_concrete",
            "brown_concrete", "green_concrete", "red_concrete", "black_concrete");
        put(12, "white_concrete_powder", "orange_concrete_powder", "magenta_concrete_powder",
            "light_blue_concrete_powder", "yellow_concrete_powder", "lime_concrete_powder",
            "pink_concrete_powder", "gray_concrete_powder", "light_gray_concrete_powder",
            "cyan_concrete_powder", "purple_concrete_powder", "blue_concrete_powder",
            "brown_concrete_powder", "green_concrete_powder", "red_concrete_powder",
            "black_concrete_powder");
        put(25, "white_terracotta", "orange_terracotta", "magenta_terracotta",
            "light_blue_terracotta", "yellow_terracotta", "lime_terracotta",
            "pink_terracotta", "gray_terracotta", "light_gray_terracotta",
            "cyan_terracotta", "purple_terracotta", "blue_terracotta",
            "brown_terracotta", "green_terracotta", "red_terracotta",
            "black_terracotta");
        put(30, "white_glazed_terracotta", "orange_glazed_terracotta",
            "magenta_glazed_terracotta", "light_blue_glazed_terracotta",
            "yellow_glazed_terracotta", "lime_glazed_terracotta",
            "pink_glazed_terracotta", "gray_glazed_terracotta",
            "light_gray_glazed_terracotta", "cyan_glazed_terracotta",
            "purple_glazed_terracotta", "blue_glazed_terracotta",
            "brown_glazed_terracotta", "green_glazed_terracotta",
            "red_glazed_terracotta", "black_glazed_terracotta");

        // Signs: hanging signs are +2 over ordinary signs.
        put(10, "oak_sign", "spruce_sign", "birch_sign", "jungle_sign",
            "acacia_sign", "dark_oak_sign", "mangrove_sign", "cherry_sign",
            "bamboo_sign", "crimson_sign", "warped_sign");
        put(12, "oak_hanging_sign", "spruce_hanging_sign", "birch_hanging_sign",
            "jungle_hanging_sign", "acacia_hanging_sign", "dark_oak_hanging_sign",
            "mangrove_hanging_sign", "cherry_hanging_sign", "bamboo_hanging_sign",
            "crimson_hanging_sign", "warped_hanging_sign");

        // Cooked foods follow the agreed raw +10 rule where a raw form exists.
        put(15, "cooked_cod", "cooked_beef", "cooked_porkchop",
            "cooked_chicken", "cooked_mutton", "cooked_rabbit");
        put(18, "cooked_salmon");
        put(15, "bread", "cookie", "pumpkin_pie", "rabbit_stew", "mushroom_stew");
    }

    private LuckValues() {}

    private static void put(int value, String... paths) {
        for (String path : paths) VALUES.put(path, value);
    }

    public static int perItem(Item item) {
        ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
        if (key == null) return 5;
        String path = key.getPath();

        // Explicit values always win.
        Integer exact = VALUES.get(path);
        if (exact != null) return exact;

        // Enchanted books are intentionally excluded from the economy.
        if ("enchanted_book".equals(path)) return 0;

        // Rarer items / special loot.
        if (path.contains("music_disc")) return 250;
        if (path.contains("banner_pattern")) return 100;
        if (path.contains("sniffer_egg")) return 500;
        if (path.contains("suspicious_sand") || path.contains("suspicious_gravel")) return 10;
        if (path.contains("spawn_egg")) return 300;
        if (path.contains("pottery_shard")) return 80;
        if (path.contains("template") || path.contains("smithing")) return 150;
        if (path.contains("head") || path.contains("skull")) return 250;
        if (path.contains("totem")) return 1000;
        if (path.contains("trident")) return 200;
        if (path.contains("elytra")) return 2000;
        if (path.contains("netherite")) return 300;
        if (path.contains("diamond")) return 150;
        if (path.contains("emerald")) return 100;
        if (path.contains("gold")) return 30;
        if (path.contains("iron")) return 20;
        if (path.contains("copper")) return 10;
        if (path.contains("redstone")) return 20;
        if (path.contains("lapis")) return 20;
        if (path.contains("amethyst")) return 15;
        if (path.contains("quartz")) return 10;

        // Tools and armour: tiered by material.
        if (path.contains("netherite_")) return 400;
        if (path.contains("diamond_") && (path.contains("sword") || path.contains("pickaxe")
                || path.contains("axe") || path.contains("shovel") || path.contains("hoe")
                || path.contains("helmet") || path.contains("chestplate")
                || path.contains("leggings") || path.contains("boots"))) return 200;
        if (path.contains("iron_") && (path.contains("sword") || path.contains("pickaxe")
                || path.contains("axe") || path.contains("shovel") || path.contains("hoe")
                || path.contains("helmet") || path.contains("chestplate")
                || path.contains("leggings") || path.contains("boots"))) return 50;
        if (path.contains("golden_") || path.contains("gold_")) return 30;
        if (path.contains("wooden_") || path.contains("stone_")) return 10;

        // Common natural and decorative items get a non-zero, predictable baseline.
        if (path.endsWith("_sapling") || path.endsWith("_leaves")
                || path.endsWith("_flower") || path.endsWith("_tulip")
                || path.endsWith("_orchid") || path.endsWith("_daisy")) return 5;
        if (path.contains("coral") || path.contains("prismarine")) return 20;
        if (path.contains("terracotta")) return 20;
        if (path.contains("wool")) return 10;
        if (path.contains("carpet")) return 15;
        if (path.contains("concrete")) return 15;
        if (path.contains("boat")) return 20;
        if (path.contains("minecart")) return 40;
        if (path.contains("fish")) return 10;
        if (path.contains("potion")) return 30;
        if (path.contains("bucket")) return 20;
        if (path.contains("egg")) return 5;
        if (path.contains("seed")) return 3;
        if (path.contains("dirt") || path.contains("grass_block")) return 1;

        // Final vanilla/modded fallback. Unlike the old temporary value of 1,
        // ordinary unlisted items no longer all collapse to the same minimum.
        return 5;
    }

    public static int luckOfStack(ItemStack stack) {
        if (stack.isEmpty()) return 0;
        return perItem(stack.getItem()) * stack.getCount();
    }

    public static int chanceBasisPoints(ItemStack stake, ItemStack reward) {
        long x = luckOfStack(stake);
        long y = luckOfStack(reward);
        if (x <= 0 || y <= 0) return 0;
        int rounded = (int) Math.round((x * 10000.0) / (x + y));
        return Math.max(1, Math.min(9999, rounded));
    }
}
