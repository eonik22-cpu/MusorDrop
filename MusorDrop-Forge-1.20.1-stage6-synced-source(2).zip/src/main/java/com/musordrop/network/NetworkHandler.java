package com.musordrop.network;

import com.musordrop.MusorDropMod;
import com.musordrop.menu.MusorDropMenu;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public final class NetworkHandler {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MusorDropMod.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private NetworkHandler() {}

    public static void register() {
        CHANNEL.registerMessage(0, SelectRewardPacket.class,
                SelectRewardPacket::encode, SelectRewardPacket::decode,
                SelectRewardPacket::handle);
        CHANNEL.registerMessage(1, SpinFinishedPacket.class,
                SpinFinishedPacket::encode, SpinFinishedPacket::decode,
                SpinFinishedPacket::handle);
    }

    public record SelectRewardPacket(int menuId, ResourceLocation itemId, int count) {
        public static void encode(SelectRewardPacket packet, net.minecraft.network.FriendlyByteBuf buf) {
            buf.writeVarInt(packet.menuId);
            buf.writeResourceLocation(packet.itemId);
            buf.writeVarInt(packet.count);
        }

        public static SelectRewardPacket decode(net.minecraft.network.FriendlyByteBuf buf) {
            return new SelectRewardPacket(buf.readVarInt(), buf.readResourceLocation(), buf.readVarInt());
        }

        public static void handle(SelectRewardPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
            NetworkEvent.Context context = contextSupplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player == null || !(player.containerMenu instanceof MusorDropMenu menu)
                        || menu.containerId != packet.menuId) return;
                Item item = BuiltInRegistries.ITEM.get(packet.itemId);
                if (item == Items.AIR) return;
                menu.setSelectedReward(new ItemStack(item, Math.max(1, Math.min(item.getMaxStackSize(), packet.count))));
            });
            context.setPacketHandled(true);
        }
    }

    public record SpinFinishedPacket(int menuId) {
        public static void encode(SpinFinishedPacket packet, net.minecraft.network.FriendlyByteBuf buf) {
            buf.writeVarInt(packet.menuId);
        }

        public static SpinFinishedPacket decode(net.minecraft.network.FriendlyByteBuf buf) {
            return new SpinFinishedPacket(buf.readVarInt());
        }

        public static void handle(SpinFinishedPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
            NetworkEvent.Context context = contextSupplier.get();
            context.enqueueWork(() -> {
                ServerPlayer player = context.getSender();
                if (player != null && player.containerMenu instanceof MusorDropMenu menu
                        && menu.containerId == packet.menuId) {
                    menu.finishSpinAnimation();
                }
            });
            context.setPacketHandled(true);
        }
    }
}
