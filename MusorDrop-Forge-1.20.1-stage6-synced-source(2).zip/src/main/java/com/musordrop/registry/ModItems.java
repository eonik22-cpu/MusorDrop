package com.musordrop.registry;

import com.musordrop.MusorDropMod;
import com.musordrop.item.MusorDropItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MusorDropMod.MOD_ID);

    public static final RegistryObject<Item> MUSOR_DROP = ITEMS.register("musor_drop",
            () -> new MusorDropItem(new Item.Properties().stacksTo(1)));
}
