package com.musordrop.registry;

import com.musordrop.MusorDropMod;
import com.musordrop.menu.MusorDropMenu;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, MusorDropMod.MOD_ID);

    public static final RegistryObject<MenuType<MusorDropMenu>> MUSOR_DROP_MENU =
            MENUS.register("musor_drop", () -> IForgeMenuType.create(MusorDropMenu::new));

    private ModMenus() {}
}
