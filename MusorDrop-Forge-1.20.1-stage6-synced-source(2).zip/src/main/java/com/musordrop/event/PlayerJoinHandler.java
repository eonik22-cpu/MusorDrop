package com.musordrop.event;

import com.musordrop.MusorDropMod;
import com.musordrop.registry.ModItems;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MusorDropMod.MOD_ID)
public final class PlayerJoinHandler {
    private static final String GIVEN_TAG = "musordrop_received_starting_item";

    private PlayerJoinHandler() {}

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.getPersistentData().getBoolean(GIVEN_TAG)) return;

        ItemStack drop = new ItemStack(ModItems.MUSOR_DROP.get());
        if (!player.getInventory().add(drop)) {
            player.drop(drop, false);
        }
        player.getPersistentData().putBoolean(GIVEN_TAG, true);
    }
}
