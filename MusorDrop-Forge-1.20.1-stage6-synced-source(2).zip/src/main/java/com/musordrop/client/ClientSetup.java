package com.musordrop.client;

import com.musordrop.MusorDropMod;
import com.musordrop.registry.ModMenus;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = MusorDropMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    // Forge 47.x (1.20.1): RegisterMenuScreensEvent does not exist here (it is a NeoForge 1.20.5+ API),
    // screens are registered through MenuScreens.register during client setup.
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> MenuScreens.register(ModMenus.MUSOR_DROP_MENU.get(), MusorDropScreen::new));
    }
}
