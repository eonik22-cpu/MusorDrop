package com.musordrop.client;

import com.musordrop.network.NetworkHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RewardPickerScreen extends Screen {
    private static final int COLS = 9;
    private static final int ROWS = 5;
    private static final int CELL = 24;
    private final MusorDropScreen parent;
    private final int menuId;
    private final List<Item> allItems = new ArrayList<>();
    private EditBox searchBox;
    private EditBox countBox;
    private Item selectedItem;
    private int page;

    public RewardPickerScreen(MusorDropScreen parent, int menuId) {
        super(Component.literal("Выбор награды"));
        this.parent = parent;
        this.menuId = menuId;
        for (Item item : BuiltInRegistries.ITEM) {
            if (!item.getDefaultInstance().isEmpty()) allItems.add(item);
        }
    }

    @Override
    protected void init() {
        int panelLeft = (width - 260) / 2;
        int panelTop = (height - 230) / 2;
        searchBox = new EditBox(font, panelLeft + 8, panelTop + 28, 170, 18,
                Component.literal("Поиск"));
        searchBox.setHint(Component.literal("Название предмета..."));
        searchBox.setResponder(value -> page = 0);
        addRenderableWidget(searchBox);

        countBox = new EditBox(font, panelLeft + 188, panelTop + 28, 64, 18,
                Component.literal("Количество"));
        countBox.setValue("1");
        countBox.setFilter(value -> value.isEmpty() || value.matches("\\d{1,2}"));
        addRenderableWidget(countBox);

        addRenderableWidget(Button.builder(Component.literal("‹"), b -> {
            if (page > 0) page--;
        }).bounds(panelLeft + 8, panelTop + 205, 28, 18).build());
        addRenderableWidget(Button.builder(Component.literal("›"), b -> {
            int pages = Math.max(1, (filteredItems().size() + COLS * ROWS - 1) / (COLS * ROWS));
            if (page + 1 < pages) page++;
        }).bounds(panelLeft + 40, panelTop + 205, 28, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Выбрать"), b -> confirm())
                .bounds(panelLeft + 166, panelTop + 203, 86, 20).build());
    }

    private List<Item> filteredItems() {
        String query = searchBox == null ? "" : searchBox.getValue().trim().toLowerCase(Locale.ROOT);
        if (query.isEmpty()) return allItems;
        List<Item> result = new ArrayList<>();
        for (Item item : allItems) {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
            String name = Component.translatable(item.getDescriptionId()).getString().toLowerCase(Locale.ROOT);
            if (name.contains(query) || id.toString().toLowerCase(Locale.ROOT).contains(query)) {
                result.add(item);
            }
        }
        return result;
    }

    private void confirm() {
        if (selectedItem == null || minecraft == null) return;
        int count;
        try {
            count = Integer.parseInt(countBox.getValue());
        } catch (NumberFormatException ignored) {
            count = 1;
        }
        count = Math.max(1, Math.min(selectedItem.getMaxStackSize(), count));
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(selectedItem);
        NetworkHandler.CHANNEL.sendToServer(
                new NetworkHandler.SelectRewardPacket(menuId, id, count));
        minecraft.setScreen(parent);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        int left = (width - 260) / 2;
        int top = (height - 230) / 2;
        graphics.fill(left, top, left + 260, top + 230, 0xFF090510);
        graphics.fill(left + 2, top + 2, left + 258, top + 228, 0xFF28133B);
        graphics.fill(left + 4, top + 4, left + 256, top + 22, 0xFF6E35A0);
        graphics.drawCenteredString(font, "ВЫБОР НАГРАДЫ", width / 2, top + 10, 0xFFFFFFFF);
        graphics.drawString(font, "Поиск", left + 8, top + 17, 0xFFE7C8FF);
        graphics.drawString(font, "Кол-во", left + 188, top + 17, 0xFFE7C8FF);

        List<Item> items = filteredItems();
        int pageSize = COLS * ROWS;
        int pages = Math.max(1, (items.size() + pageSize - 1) / pageSize);
        page = Math.min(page, pages - 1);
        int startX = left + 8;
        int startY = top + 56;
        int start = page * pageSize;
        for (int i = 0; i < pageSize && start + i < items.size(); i++) {
            int col = i % COLS;
            int row = i / COLS;
            int x = startX + col * CELL;
            int y = startY + row * CELL;
            Item item = items.get(start + i);
            boolean chosen = item == selectedItem;
            graphics.fill(x, y, x + 22, y + 22, chosen ? 0xFFB66BEE : 0xFF10091A);
            graphics.renderItem(item.getDefaultInstance(), x + 3, y + 3);
            if (mouseX >= x && mouseX < x + 22 && mouseY >= y && mouseY < y + 22) {
                graphics.renderTooltip(font, item.getDefaultInstance(), mouseX, mouseY);
            }
        }
        graphics.drawString(font, "Страница " + (page + 1) + " / " + pages,
                left + 78, top + 210, 0xFFE7C8FF);
        if (selectedItem != null) {
            graphics.drawString(font, "Выбрано: " + Component.translatable(selectedItem.getDescriptionId()).getString(),
                    left + 8, top + 190, 0xFFFFFFFF);
        } else {
            graphics.drawString(font, "Нажми на предмет, чтобы выбрать его",
                    left + 8, top + 190, 0xFFBFA8D1);
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int left = (width - 260) / 2;
        int top = (height - 230) / 2;
        int startX = left + 8;
        int startY = top + 56;
        if (button == 0 && mouseX >= startX && mouseX < startX + COLS * CELL
                && mouseY >= startY && mouseY < startY + ROWS * CELL) {
            int col = (int) (mouseX - startX) / CELL;
            int row = (int) (mouseY - startY) / CELL;
            int index = page * COLS * ROWS + row * COLS + col;
            List<Item> items = filteredItems();
            if (index >= 0 && index < items.size()) {
                selectedItem = items.get(index);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void onClose() {
        if (minecraft != null) minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
