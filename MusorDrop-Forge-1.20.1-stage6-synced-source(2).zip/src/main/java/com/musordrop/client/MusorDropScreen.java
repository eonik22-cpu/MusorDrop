package com.musordrop.client;

import com.musordrop.menu.MusorDropMenu;
import com.musordrop.network.NetworkHandler;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public class MusorDropScreen extends AbstractContainerScreen<MusorDropMenu> {
    private static final int WHEEL_RADIUS = 38;
    private long spinStartedAt = 0L;
    private int observedSpinSequence;
    private boolean spinning;
    private boolean spinRequestPending;
    private double currentSpinAngle;
    private double spinStartAngle;
    private double spinTargetAngle;
    private static final double SPIN_DURATION_SECONDS = 2.4;

    public MusorDropScreen(MusorDropMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 256;
        this.imageHeight = 220;
        this.inventoryLabelY = 128;
        this.observedSpinSequence = menu.getSpinSequence();
    }

    @Override
    protected void init() {
        super.init();
        int left = (this.width - this.imageWidth) / 2;
        int top = (this.height - this.imageHeight) / 2;
        this.addRenderableWidget(Button.builder(Component.literal("КРУТИТЬ!"), button -> {
            if (this.minecraft != null && this.minecraft.gameMode != null && this.menu.hasValidOffer() && !this.spinning && !this.spinRequestPending) {
                // The server decides the result. The wheel animation begins only after
                // the synchronized result/sequence arrives back from the server.
                this.spinRequestPending = true;
                this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, 0);
            }
        }).bounds(left + 94, top + 111, 68, 20).build());
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // The right slot is a reward selector, not a physical inventory slot.
        if (mouseX >= this.leftPos + 212 && mouseX < this.leftPos + 230
                && mouseY >= this.topPos + 54 && mouseY < this.topPos + 72) {
            if (!spinning && !spinRequestPending && this.minecraft != null) {
                this.minecraft.setScreen(new RewardPickerScreen(this, this.menu.containerId));
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int l = (this.width - this.imageWidth) / 2;
        int t = (this.height - this.imageHeight) / 2;

        // Main frame: original Musor Drop purple palette.
        g.fill(l, t, l + imageWidth, t + imageHeight, 0xFF090510);
        g.fill(l + 2, t + 2, l + imageWidth - 2, t + imageHeight - 2, 0xFF6E35A0);
        g.fill(l + 4, t + 4, l + imageWidth - 4, t + imageHeight - 4, 0xFF1B1028);
        g.fill(l + 6, t + 6, l + imageWidth - 6, t + 22, 0xFF482069);
        g.drawCenteredString(this.font, Component.literal("МУСОР ДРОП"), l + imageWidth / 2, t + 10, 0xFFFFFFFF);

        // Bet and prize panels. Actual item stacks are rendered in native slots.
        drawPanel(g, l + 12, t + 35, 58, 43);
        drawPanel(g, l + 186, t + 35, 58, 43);
        g.drawCenteredString(this.font, Component.literal("СТАВКА"), l + 41, t + 25, 0xFFE7C8FF);
        g.drawCenteredString(this.font, Component.literal("ВЫИГРЫШ"), l + 215, t + 25, 0xFFE7C8FF);

        // Wheel base and percentage-sized winning sector.
        int cx = l + 128;
        int cy = t + 57;
        double shownChance = menu.getChancePercent();
        if (shownChance <= 0.0 && menu.getSpinSequence() > 0) {
            shownChance = menu.getLastSpinChancePercent();
        }
        double chance = Math.max(0.0, Math.min(100.0, shownChance));
        double sectorRadians = Math.PI * 2.0 * chance / 100.0;
        updateSpinAnimation();
        double spinAngle = currentSpinAngle;

        // Circular disk with a sector whose angle exactly matches the displayed chance.
        for (int dy = -WHEEL_RADIUS; dy <= WHEEL_RADIUS; dy++) {
            int runStart = Integer.MIN_VALUE;
            int lastColor = 0;
            for (int dx = -WHEEL_RADIUS; dx <= WHEEL_RADIUS; dx++) {
                boolean inside = dx * dx + dy * dy <= WHEEL_RADIUS * WHEEL_RADIUS;
                int color = 0;
                if (inside) {
                    double a = Math.atan2(dy, dx) - spinAngle;
                    a = (a % (Math.PI * 2.0) + Math.PI * 2.0) % (Math.PI * 2.0);
                    boolean winning = chance > 0 && a < sectorRadians;
                    color = winning ? 0xFFE2B8FF : 0xFF572783;
                    if (dx * dx + dy * dy > (WHEEL_RADIUS - 3) * (WHEEL_RADIUS - 3)) {
                        color = winning ? 0xFFF3DFFF : 0xFF241033;
                    }
                }
                if (color != lastColor) {
                    if (runStart != Integer.MIN_VALUE) {
                        g.fill(cx + runStart, cy + dy, cx + dx, cy + dy + 1, lastColor);
                    }
                    runStart = inside ? dx : Integer.MIN_VALUE;
                    lastColor = color;
                }
                if (!inside) {
                    if (runStart != Integer.MIN_VALUE) {
                        g.fill(cx + runStart, cy + dy, cx + dx, cy + dy + 1, lastColor);
                        runStart = Integer.MIN_VALUE;
                    }
                    lastColor = 0;
                }
            }
            if (runStart != Integer.MIN_VALUE) {
                g.fill(cx + runStart, cy + dy, cx + WHEEL_RADIUS + 1, cy + dy + 1, lastColor);
            }
        }

        // Hub, pointer, and small radial markers.
        g.fill(cx - 10, cy - 10, cx + 10, cy + 10, 0xFF170B22);
        g.fill(cx - 7, cy - 7, cx + 7, cy + 7, 0xFFB66BEE);
        g.fill(cx - 3, cy - 3, cx + 3, cy + 3, 0xFF32104F);
        g.fill(cx - 2, cy - WHEEL_RADIUS - 7, cx + 3, cy - WHEEL_RADIUS + 2, 0xFFFFD65A);
        g.fill(cx - 5, cy - WHEEL_RADIUS - 7, cx + 6, cy - WHEEL_RADIUS - 4, 0xFFFFE99A);

        String chanceText = chance > 0
                ? String.format(java.util.Locale.ROOT, "%.2f%%", chance)
                : "--";
        g.drawCenteredString(this.font, chanceText, cx, t + 101, 0xFFF1D9FF);
        g.drawCenteredString(this.font, Component.literal("ШАНС ПОБЕДЫ"), cx, t + 91, 0xFFCAA1E8);
        g.drawCenteredString(this.font, this.playerInventoryTitle, l + imageWidth / 2, t + 130, 0xFFFFFFFF);
    }

    private void updateSpinAnimation() {
        int serverSequence = menu.getSpinSequence();
        if (serverSequence != observedSpinSequence) {
            observedSpinSequence = serverSequence;
            spinRequestPending = false;
            spinning = true;
            spinStartedAt = System.nanoTime();
            spinStartAngle = currentSpinAngle;

            double chance = Math.max(0.0001, Math.min(99.9999, menu.getLastSpinChancePercent()));
            double sectorRadians = Math.PI * 2.0 * chance / 100.0;
            // The pointer is at -PI/2. Choose the center of the actual winning
            // sector for a win, or the center of the losing sector for a loss.
            double localTarget = menu.wasLastSpinWon()
                    ? sectorRadians / 2.0
                    : sectorRadians + (Math.PI * 2.0 - sectorRadians) / 2.0;
            double desiredAngle = -Math.PI / 2.0 - localTarget;
            double fullTurn = Math.PI * 2.0;
            double normalizedDifference = ((desiredAngle - spinStartAngle) % fullTurn + fullTurn) % fullTurn;
            spinTargetAngle = spinStartAngle + normalizedDifference + fullTurn * 5.0;
        }

        if (spinning) {
            double elapsed = (System.nanoTime() - spinStartedAt) / 1_000_000_000.0;
            double progress = Math.min(1.0, elapsed / SPIN_DURATION_SECONDS);
            // Ease-out cubic: several full turns, then a smooth stop on the
            // server-confirmed winning or losing sector.
            double eased = 1.0 - Math.pow(1.0 - progress, 3.0);
            currentSpinAngle = spinStartAngle + (spinTargetAngle - spinStartAngle) * eased;
            if (progress >= 1.0) {
                currentSpinAngle = spinTargetAngle;
                spinning = false;
                spinStartedAt = 0L;
                if (this.minecraft != null && this.minecraft.gameMode != null) {
                    NetworkHandler.CHANNEL.sendToServer(
                            new NetworkHandler.SpinFinishedPacket(this.menu.containerId));
                }
            }
        }
    }

    private void drawPanel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF08040D);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF9B58C9);
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, 0xFF160B22);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        this.renderTooltip(graphics, mouseX, mouseY);
    }
}
